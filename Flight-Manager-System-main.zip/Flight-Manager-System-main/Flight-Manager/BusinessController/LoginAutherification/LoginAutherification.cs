﻿using Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessController
{
    public static class LoginAutherification
    {
        public static dbUser LoggedUser { get; set; }
        public static string userName { get; set; }
    }
}
